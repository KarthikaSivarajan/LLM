from setuptools import find_packages, setup

setup(

    name = 'Interview Assignment',
    version= '0.0.0',
    author= 'AMBRISH',
    author_email= 'ambrishanandaranis@gmail.com',
    packages=find_packages(),
    install_requires = []
    
)