# RAG based - Multilingual AI Chatbot 🤖 for Indian Farmers
![alt text](max.png)


## overlay of the process
![alt text](image.png)


## devoloper's_information

# NAME:AMBRISH A
# ambrishanandaranis@gmail.com
# github profile:@AMBRISH10

<!-- 
(base)
ambri@Ambrish MINGW64 ~/OneDrive/Desktop/final
$ conda activate final
(final)
ambri@Ambrish MINGW64 ~/OneDrive/Desktop/final
$
select the environment and continue --------

ambri@Ambrish MINGW64 ~/OneDrive/Desktop/final/sense (main) -->
